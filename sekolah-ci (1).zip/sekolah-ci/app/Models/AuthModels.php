<?php

namespace App\Models;

use CodeIgniter\Model;

class AuthModels extends Model
{
        protected $table ='admin';
        protected $primaryKey = 'id';

        protected $allowedFields = [
            'username', 'password',
        ];

        protected $useAutoIncrement = true;

        public function validate_data($username, $password)
        {
            $data = [
                'username' => $username,
                'password' => $password
            ];

            $allData = $this->get();
            $admin = [];

            foreach ($allData->getResult() as $key => $value){
                if($value->username == $data['username'] && $value->password == $data['password'] ){
                    $admin = $value;
                }
            }
            return $admin;
        }
}