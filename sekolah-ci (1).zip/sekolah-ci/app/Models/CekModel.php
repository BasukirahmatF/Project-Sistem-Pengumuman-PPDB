<?php

namespace App\Models;

use CodeIgniter\Model;

class CekModel extends Model
{
    protected $table = 'data_siswa';
    protected $primaryKey = 'id';

    public function getSiswaByNomorPendaftaran($nomorPendaftaran)
    {
        return $this->where('nomor_pendaftaran', $nomorPendaftaran)->first();
    }
}
