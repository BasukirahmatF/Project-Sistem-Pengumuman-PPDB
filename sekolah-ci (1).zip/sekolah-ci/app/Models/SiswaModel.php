<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
        protected $table ='data_siswa';
        protected $primaryKey = 'id';

        protected $allowedFields = [
            'nomor_pendaftaran', 'nama_siswa', 'asal_sekolah', 'status'
        ];

        protected $useAutoIncrement = true;

        public function insert_data($nomor_pendaftaran, $nama_siswa, $asal_sekolah, $status)
        {
            
            // Cek apakah nomor pendaftaran sudah ada dalam database
            $existingData = $this->where('nomor_pendaftaran', $nomor_pendaftaran)->first();
            if ($existingData) {
                // Nomor pendaftaran sudah ada, berikan pesan kesalahan
                session()->setFlashdata('error', 'Nomor pendaftaran sudah ada dalam database.');
                return false;
            }
            $data = [
                'nomor_pendaftaran' => $nomor_pendaftaran,
                'nama_siswa' => $nama_siswa,
                'asal_sekolah' => $asal_sekolah,
                'status' => $status
            ];

            $this->insert($data);
              // Berikan pesan sukses
            session()->setFlashdata('success', 'Data siswa berhasil ditambahkan.');
            return true;

        }

        public function update_data($id, $data)
        {
            $this->update($id, $data);
        }


        public function select_data($id)
        {
            $select = $this->query("SELECT * FROM `data_siswa` WHERE id = $id ");
            return $select->getRow();
        }

        public function select_all_data()
        {
            $getAllData = $this->query('SELECT * FROM `data_siswa`;')->getResult();
            return $getAllData;
        }
}


?>