<!DOCTYPE html>
<html>

<head>
<link rel="icon" href="<?= base_url('images/sman-1-margahayu.png')?>">

  <title>Login Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    .error {
      color: red;
    }
  </style>
</head>

<body class="bg-gray-200 flex items-center justify-center h-screen">
  <div class="max-w-sm p-6 bg-white rounded shadow-md">
    <h1 class="text-2xl mb-6 text-center">Admin</h1>
   
    <form method="post" action="<?= base_url('admin/login'); ?>">
      <div class="mb-4">
        <label for="username" class="block mb-2">Username:</label>
        <input type="text" id="username" name="username" placeholder="Username" class="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300">
      </div>
      <div class="mb-6">
        <label for="password" class="block mb-2">Password:</label>
        <input type="password" id="password" name="password" placeholder="Password" class="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300">
      </div>
      <div class="flex justify-center">
        <input type="submit" value="Login" class="w-full px-6 py-2 text-white bg-blue-500 rounded cursor-pointer">
      </div>
    </form>
  </div>
</body>

</html>
