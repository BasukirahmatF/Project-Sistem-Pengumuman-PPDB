<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="<?= base_url('images/sman-1-margahayu.png')?>">
<title>SMAN 1 Margahayu</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<div class="bg-gradient-to-r from-cyan-300 to-blue-500 lg:h-screen md:h-[100%] w-screen flex flex-col items-center justify-center absolute left-0 right-0 w-[100%] p-0">
  <div class="w-full lg:px-[10%] md:px-[4%] md:h-[60vh]">
    <div class="bg-gray-100 bg-opacity-50 lg:w-2/3 m-auto lg:px-8 md:px-4 py-6 lg:h-auto h-auto md:w-full rounded-md">
        <div class="lg:h-[60px] md:h-[110px]">
    <div class="container mx-auto flex items-center justify-center px-4">
      <a href="https://www.sman1margahayu.sch.id/">
        <img src="<?= base_url('images/logo-margahayu.png')?>" alt="logosman1margahayu" class="lg:w-[300px] md:w-[500px] lg:h-auto">
      </a>
      <a href="https://www.sman1margahayu.sch.id/">
        <img src="<?= base_url('images/logo-ppdb-2023.png')?>" alt="logosman1margahayu" class="lg:w-[200px] md:w-[300px] lg:h-auto pb-2">
      </a>
    </div>
  </div>
  <h1 class="lg:text-lg md:text-[28px] font-bold mb-2 lg:mt-4 md:mt-6 lg:text-center md:text-center md:py-6 underline underline-offset-4">PENGUMUMAN SELEKSI SISWA SMA NEGERI 1 MARGAHAYU PPDB 2023/2024</h1>
  <!-- <p class="text-red-500 lg:text-[16px] md:text-[24px] font-bold">Silahkan isi pada form dibawah,sesuai dengan nomor pendaftaran anda.</p> -->
  <form class="mb-4" method="post" action="<?= base_url('/status')?>">
    <label class="block mb-2 lg:text-[16px] md:text-[24px]" for="nomor_pendaftaran">Nomor Pendaftaran:</label>
    <input class="border border-gray-300 px-4 py-2 w-full mb-2 lg:h-[8vh] md:h-[4vh] rounded-md lg:text-[16px] md:text-[24px]" type="text" id="nomor_pendaftaran" name="nomor_pendaftaran" placeholder="Masukkan nomor pendaftaran siswa">
    <input class="bg-blue-700 text-white px-4 py-2 w-full lg:h-[6vh] md:h-[4vh] my-2 lg:text-[16px] md:text-[22px] rounded-md" type="submit" value="Lihat Hasil">
  </form>

  <?php if (session()->has('error')): ?>
    <p class="text-red-500"><?= session('error') ?></p>
  <?php endif; ?>

</div>
</div>
</div>
</body>
</html>
