<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="<?= base_url('images/sman-1-margahayu.png')?>">
<title>SMAN 1 Margahayu</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<div class="bg-gradient-to-r from-cyan-300 to-blue-500 lg:h-screen md:h-[100%] w-screen flex flex-col items-center justify-center absolute left-0 right-0 w-[100%] p-0">
  <div class="w-full lg:px-[10%] md:px-[4%] md:h-[60vh]">
    <div class="bg-gray-100 bg-opacity-50 lg:w-2/3 m-auto lg:px-8 md:px-4 py-6 lg:h-auto h-auto md:w-full rounded-md">
        <div class="lg:h-[60px] md:h-[110px]">
          <div class="container mx-auto flex items-center justify-center px-4">
            <a href="https://www.sman1margahayu.sch.id/">
              <img src="<?= base_url('images/logo-margahayu.png')?>" alt="logosman1margahayu" class="lg:w-[300px] md:w-[500px] lg:h-auto">
            </a>
            <a href="https://www.sman1margahayu.sch.id/">
              <img src="<?= base_url('images/logo-ppdb-2023.png')?>" alt="logosman1margahayu" class="lg:w-[200px] md:w-[300px] lg:h-auto pb-2">
            </a>
          </div>
        </div>
      <h1 class="lg:text-lg md:text-[28px] font-bold mb-2 lg:mt-4 md:mt-6 lg:text-center md:text-center md:py-6 underline underline-offset-4">PENGUMUMAN SELEKSI SISWA SMA NEGERI 1 MARGAHAYU PPDB 2023/2024</h1>
      <p class="lg:text-[16px] md:text-[26px] font-bold md:mt-10 md:text-center">Nomor pendaftaran <span class="text-<?= $siswa['nomor_pendaftaran'] ?>-500 font-bold bg-white p-1"><?= $siswa['nomor_pendaftaran'] ?></span> dinyatakan <span class="text-<?= $siswa['status'] == 'DITERIMA' ? 'green' : 'red' ?>-500 font-bold bg-white p-1"><?= $siswa['status'] ?></span></p>
      <div class="overflow-x-auto mt-6 px-[6%]">
          <table class="min-w-full bg-blue-500 p-2 min-h-full rounded-md">
            <thead>
              <tr>
                <th class="py-2 text-white lg:text-lg md:text-[28px]">Nama Siswa :</th>
                <td class="py-2 text-white lg:text-lg md:text-[28px]" style="text-transform: uppercase;"><?= $siswa['nama_siswa'] ?></td>
              </tr>
              <tr>
                <th class="py-2  text-white lg:text-lg md:text-[28px]">Asal Sekolah :</th>
                <td class="py-2  text-white lg:text-lg md:text-[28px]" style="text-transform: uppercase;"><?= $siswa['asal_sekolah'] ?></td>
              </tr>
            </thead>
          </table>
        </div>



      <p class="lg:mt-4 md:mt-[10%] mt-8 lg:pl-10 md:pl-10">
        <?php if ($siswa['status'] == 'DITERIMA'): ?>
          <span class="text-red-500 lg:text-lg md:text-[28px]">Silakan melanjutkan langkah selanjutnya.</span>
          <a class="inline-block px-4 py-2 lg:text-sm md:text-[20px] font-bold leading-5 text-white transition-colors duration-150 bg-blue-500 border border-transparent rounded-md active:bg-blue-600 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue" href="<?= 'https://forms.google.com'?>">Klik Untuk Verifikasi</a>
        <?php endif; ?>
      </p>
      <!-- Tombol Kembali -->
      <!-- <a class="mt-4 lg:ml-[80%] md:ml-[80%] inline-block px-4 py-2 text-md font-medium leading-5 text-white transition-colors duration-150 bg-gray-500 border border-transparent rounded-md active:bg-gray-600 hover:bg-gray-700 focus:outline-none focus:shadow-outline-gray" href="<?= site_url('/') ?>">Kembali</a> -->

    </div>
    
  </div>
</div>
</body>
</html>
