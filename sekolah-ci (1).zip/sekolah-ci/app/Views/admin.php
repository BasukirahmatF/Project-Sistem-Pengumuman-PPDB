<?php
session_start();


?>

<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="<?= base_url('images/sman-1-margahayu.png')?>">
<title>SMAN 1 Margahayu</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<header class="bg-blue-500 h-[60px] py-4 flex justify-around">
  <div class="container mx-auto flex items-center justify-around">
    <a href="https://www.sman1margahayu.sch.id/">
      <img src="<?= base_url('images/logo-margahayu.png')?>" alt="logosman1margahayu" class="w-28 h-auto">
    </a>
    <p class="bg-white text-black px-2 py-2"><a href="<?= base_url('/logout')?>">Keluar</a></p>
  </div>
</header>

<div class="container mx-auto lg:px-[12%] md:px-[0%] px-0 mt-8">
  <form class="mt-4 lg:w-[60%] w-full mx-auto" action="<?= base_url('/admin'); ?>" enctype="multipart/form-data" method="post">
      <label class="block mb-2" for="nomor_pendaftaran">Nomor Pendaftaran:</label>
      <input class="border border-gray-300 px-4 py-2 w-full mb-2" type="text" id="nomor_pendaftaran" name="nomor_pendaftaran" placeholder="Masukkan nomor pendaftaran" required>
      <label class="block mb-2" for="nama_siswa">Nama Siswa:</label>
      <input class="border border-gray-300 px-4 py-2 w-full mb-2" type="text" id="nama_siswa" name="nama_siswa" placeholder="Masukkan nama siswa" style="text-transform: uppercase;" required>
      <label class="block mb-2" for="asal_sekolah">Asal Sekolah:</label>
      <input class="border border-gray-300 px-4 py-2 w-full mb-2" type="text" id="asal_sekolah" name="asal_sekolah" placeholder="Masukkan asal sekolah" style="text-transform: uppercase;" required>
      <label class="block mb-2" for="status">Status:</label>
      <select class="border border-gray-300 px-4 py-2 w-full mb-2" id="status" name="status" onChange="document.getElementById('form_id').submit();">
        <option value="">--Pilih Status--</option>
        <option <?php if(!empty($cari) && $cari == 'DITERIMA') { echo 'selected'; } ?> value="DITERIMA">DITERIMA</option>
        <option <?php if(!empty($cari) && $cari == 'TIDAK DITERIMA') { echo 'selected'; } ?> value="TIDAK DITERIMA">TIDAK DITERIMA</option>
      </select>
      <input class="w-full bg-blue-500 text-white px-4 py-2 mt-2 rounded-md" type="submit" value="Tambah Data Calon Siswa">
  </form>

  <?php if (session()->has('error')) : ?>
    <div class="mt-6 text-red-600 alert alert-danger">
        <?= session()->getFlashdata('error') ?>
    </div>
  <?php endif ?>

  <?php if (session()->has('success')) : ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
    </div>
  <?php endif ?>

  <table class="bg-white mt-8 w-full border-collapse border border-gray-300 mb-4">
    <tr>
      <th class="border border-gray-300 lg:px-4 md:px-4 px-0 py-2">No</th>
      <th class="border border-gray-300 lg:px-4 md:px-4 px-0 py-2">Nomor Pendaftaran</th>
      <th class="border border-gray-300 lg:px-4 md:px-4 px-0">Nama Siswa</th>
      <th class="border border-gray-300 lg:px-4 md:px-4 px-0">Asal Sekolah</th>
      <th class="border border-gray-300 lg:px-4 md:px-4 px-0">Status</th>
      <th class="border border-gray-300 lg:px-4 md:px-4 px-0">Aksi</th>
    </tr>

    <?php $noUrut = 1; ?>
    <?php foreach ($data_siswa as $value) : ?>      
      <tr>
        <td class="border border-gray-300 px-4 py-2 text-center"><?= $noUrut; $noUrut++; ?></td>
        <td class="border border-gray-300 px-4 py-2"><?= $value->nomor_pendaftaran; ?></td>
        <td class="border border-gray-300 px-4 py-2" style="text-transform: uppercase;"><?= $value->nama_siswa; ?></td>
        <td class="border border-gray-300 px-4 py-2" style="text-transform: uppercase;"><?= $value->asal_sekolah; ?></td>
        <td class="border border-gray-300 px-4 py-2"><?= $value->status; ?></td>
        <td class="border border-gray-300 px-4 py-2">
            <a href="<?= base_url("admin/edit/{$value->id}"); ?>" class="bg-blue-700 text-white px-4 p-2">Edit</a>
            <a href="<?= base_url ("delete/$value->id"); ?>" class="bg-red-500 text-white px-4 p-2 ml-2">Hapus</a>
        </td>
      </tr>
    <?php endforeach; ?>

  </table>
  

</div>
</body>
</html>
