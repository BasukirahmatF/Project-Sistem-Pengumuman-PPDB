<?php
session_start();


?>

<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="<?= base_url('images/sman-1-margahayu.png')?>">
<title>SMAN 1 Margahayu</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<header class="bg-blue-500 h-[60px] py-4 flex justify-around">
  <div class="container mx-auto flex items-center justify-around">
    <a href="https://www.sman1margahayu.sch.id/">
      <img src="<?= base_url('images/logo-margahayu.png')?>" alt="logosman1margahayu" class="w-28 h-auto">
    </a>
    <p class="bg-white text-black px-2 py-2"><a href="<?= base_url('/logout')?>">Keluar</a></p>
  </div>
</header>

<div class="container mx-auto lg:px-[12%] md:px-[0%] px-0 mt-8">
  <form class="mt-4 lg:w-[60%] w-full mx-auto" action="<?= base_url('update'); ?>" enctype="multipart/form-data" method="post">
  
  <input type="hidden" name="id" value="<?= $data_siswa['id']; ?>">

    <label class="block mb-2" for="nomor_pendaftaran">Nomor Pendaftaran:</label>
    <input class="border border-gray-300 px-4 py-2 w-full mb-2" type="text" id="nomor_pendaftaran" name="nomor_pendaftaran" placeholder="Masukkan nomor pedaftaran" value="<?= $data_siswa['nomor_pendaftaran']; ?>" required>
    <label class="block mb-2" for="nama_siswa">Nama Siswa:</label>
    <input class="border border-gray-300 px-4 py-2 w-full mb-2" type="text" id="nama_siswa" name="nama_siswa" placeholder="Masukkan nama siswa"value="<?= $data_siswa['nama_siswa']; ?>" style="text-transform: uppercase;" required>
    <label class="block mb-2" for="asal_sekolah">Asal Sekolah:</label>
    <input class="border border-gray-300 px-4 py-2 w-full mb-2" type="text" id="asal_sekolah" name="asal_sekolah" placeholder="Masukkan asal sekolah" value="<?= $data_siswa['asal_sekolah']; ?>" style="text-transform: uppercase;" required>
    <label class="block mb-2" for="status">Status:</label>
    <select class="border border-gray-300 px-4 py-2 w-full mb-2" id="status" name="status" onChange="document.getElementById('form_id').submit();">
      <option value="">--Pilih Status--</option>
      <option <?php if($data_siswa['status'] == 'DITERIMA') { echo 'selected'; } ?> value="DITERIMA">DITERIMA</option>
      <option <?php if($data_siswa['status'] == 'TIDAK DITERIMA') { echo 'selected'; } ?> value="TIDAK DITERIMA">TIDAK DITERIMA</option>
    </select>
    
    <input class="w-full bg-blue-500 text-white px-4 py-2 mt-2 rounded-md" type="submit" value="Simpan Perubahan">
    <a class=" w-full mt-4 inline-block text-center  px-4 py-2 text-md font-medium leading-5 text-white transition-colors duration-150 bg-gray-500 border border-transparent rounded-md active:bg-gray-600 hover:bg-gray-700 focus:outline-none focus:shadow-outline-gray" href="<?= site_url('/admin') ?>">Kembali</a>
  </form>
  
  
  
</div>
</body>
</html>
