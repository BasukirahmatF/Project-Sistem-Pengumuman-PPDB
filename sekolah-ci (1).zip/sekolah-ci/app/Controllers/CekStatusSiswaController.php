<?php

namespace App\Controllers;

use App\Models\CekModel;
use CodeIgniter\Controller;

class CekStatusSiswaController extends Controller
{
    public function index()
    {
        return view('cek_status_siswa');
    }

    public function cekStatus()
    {
        $model = new CekModel(); 

        $nomorPendaftaran = $this->request->getPost('nomor_pendaftaran');

        $siswa = $model->getSiswaByNomorPendaftaran($nomorPendaftaran);

        if ($siswa !== null) {
            return view('hasil_pencarian', ['siswa' => $siswa]);
        } else {
            return redirect()->back()->with('error', 'Nomor pendaftaran tidak ditemukan, Harap Isikan dengan benar.');
        }
    }
}
