<?php

namespace App\Controllers;

use App\Models\AuthModels;

class Auth extends BaseController
{
    public function login_admin()
    {
        $data = [
            'validation' => \Config\Services::validation()
        ];

        return view('login');
    }

    public function login_process()
    {
        $session = session();
        $process_model = new AuthModels();

        $username = $_REQUEST['username'];
        $password = $_REQUEST['password'];

        $check = $process_model->validate_data($username, $password);

        if($check){
            $data = [
                'id' =>$check->id,
                'username' =>$check->username,
                'password' =>$check->password,
            ];
            $session->set($data);
            return redirect()->to('admin');
        }else{
            return redirect()->to('admin/login');
        }
    }

    public function logout_process()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('admin/login');
    }
}
