<?php

namespace App\Controllers;

use App\Models\SiswaModel;

class Admin extends BaseController
{
    public function admin_home()
    {
        $siswa_model = new SiswaModel();
        $session = session();
        $data = [
            'data_siswa' => $siswa_model->select_all_data()
        ];

        if($session->get('id') == null){
            return redirect()->to('admin/login');
        }else{
            return view('admin', $data);
        }
    }

    
    public function data_process()
    {
        $siswa_model = new SiswaModel();
        
        $nomor_pendaftaran = $_REQUEST['nomor_pendaftaran'];
        $nama_siswa = $_REQUEST['nama_siswa'];
        $asal_sekolah = $_REQUEST['asal_sekolah'];
        $status = $_REQUEST['status'];
        
        $siswa_model->insert_data($nomor_pendaftaran, $nama_siswa, $asal_sekolah, $status);
        return redirect()->back();
    }
    
    public function edit_data($id)
    {
        $siswa_model = new SiswaModel();
        $session = session();
        
        if($session->get('id') == null){
            return redirect()->to('admin/login');
        }else{
            $data = [
                'data_siswa' => $siswa_model->find($id)
            ];
            return view('edit', $data);
        }
    }

    public function update_process()
    {
        $siswa_model = new SiswaModel();

        $id = $this->request->getPost('id');
        $nomor_pendaftaran = $_REQUEST['nomor_pendaftaran'];
        $nama_siswa = $_REQUEST['nama_siswa'];
        $asal_sekolah = $_REQUEST['asal_sekolah'];
        $status = $_REQUEST['status'];

        $data = [
            'nomor_pendaftaran' => $nomor_pendaftaran,
            'nama_siswa' => $nama_siswa,
            'asal_sekolah' => $asal_sekolah,
            'status' => $status
        ];

        $siswa_model->update_data($id, $data);
        return redirect()->to('admin');
    }

    public function delete_process($id)
    {
        $siswa_model = new SiswaModel();
        $siswa_model->delete($id);
        return redirect()->to('admin');

    }
}
